/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.datagen.v1.provider;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.resource.conditions.v1.ConditionJsonProvider;
import net.fabricmc.fabric.impl.datagen.FabricDataGenHelper;
import net.minecraft.advancement.Advancement;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeProvider;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.data.server.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.recipe.Recipe;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

/**
 * Extend this class and implement {@link FabricRecipeProvider#method_10419}.
 *
 * <p>Register an instance of the class with {@link FabricDataGenerator.Pack#addProvider} in a {@link net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint}.
 */
public abstract class FabricRecipeProvider extends RecipeProvider {
	protected final FabricDataOutput output;

	public FabricRecipeProvider(FabricDataOutput output) {
		super(output);
		this.output = output;
	}

	/**
	 * Implement this method and then use the range of methods in {@link RecipeProvider} or from one of the recipe json factories such as {@link ShapedRecipeJsonBuilder} or {@link ShapelessRecipeJsonBuilder}.
	 */
	@Override
	public abstract void method_10419(class_8790 exporter);

	/**
	 * Return a new exporter that applies the specified conditions to any recipe json provider it receives.
	 */
	protected class_8790 withConditions(class_8790 exporter, ConditionJsonProvider... conditions) {
		Preconditions.checkArgument(conditions.length > 0, "Must add at least one condition.");
		return new class_8790() {
			@Override
			public void method_53819(Identifier identifier, Recipe<?> recipe, @Nullable class_8779 advancementEntry) {
				FabricDataGenHelper.addConditions(recipe, conditions);
				exporter.method_53819(identifier, recipe, advancementEntry);
			}

			@Override
			public Advancement.Builder method_53818() {
				return exporter.method_53818();
			}
		};
	}

	@Override
	public CompletableFuture<?> run(DataWriter writer) {
		Set<Identifier> generatedRecipes = Sets.newHashSet();
		List<CompletableFuture<?>> list = new ArrayList<>();
		method_10419(new class_8790() {
			@Override
			public void method_53819(Identifier recipeId, Recipe<?> recipe, @Nullable class_8779 advancement) {
				Identifier identifier = getRecipeIdentifier(recipeId);

				if (!generatedRecipes.add(identifier)) {
					throw new IllegalStateException("Duplicate recipe " + identifier);
				}

				JsonObject recipeJson = Util.getResult(class_1860.field_47319.encodeStart(JsonOps.INSTANCE, recipe), IllegalStateException::new).getAsJsonObject();
				ConditionJsonProvider[] conditions = FabricDataGenHelper.consumeConditions(recipe);
				ConditionJsonProvider.write(recipeJson, conditions);

				list.add(DataProvider.writeToPath(writer, recipeJson, recipesPathResolver.resolveJson(identifier)));

				if (advancement != null) {
					JsonObject advancementJson = Util.getResult(class_161.field_47179.encodeStart(JsonOps.INSTANCE, advancement.comp_1920()), IllegalStateException::new).getAsJsonObject();
					ConditionJsonProvider.write(advancementJson, conditions);
					list.add(DataProvider.writeToPath(writer, advancementJson, advancementsPathResolver.resolveJson(getRecipeIdentifier(advancement.comp_1919()))));
				}
			}

			@Override
			public Advancement.Builder method_53818() {
				return Advancement.Builder.createUntelemetered().parent(CraftingRecipeJsonBuilder.ROOT);
			}
		});
		return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
	}

	/**
	 * Override this method to change the recipe identifier. The default implementation normalizes the namespace to the mod ID.
	 */
	protected Identifier getRecipeIdentifier(Identifier identifier) {
		return new Identifier(output.getModId(), identifier.getPath());
	}
}
