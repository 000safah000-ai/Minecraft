package com.jujutsuminecraft.client.render;

import foundry.veil.api.client.render.VeilRenderSystem;
import foundry.veil.api.client.render.shader.program.ShaderProgram;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;

public class LaserVeilRenderer {
    public static final class_2960 LASER_SHADER = new class_2960("jujutsuminecraft", "laser_beam");

    public static void register() {
        // Shaders are automatically loaded by Veil if placed in assets/modid/shaders
    }
    
    public static void renderLaserCore(float time, float distance, class_4587 matrixStack) {
        // Complete GLSL rendering wrapper logic
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        
        ShaderProgram shader = VeilRenderSystem.setShader(LASER_SHADER);
        if (shader != null) {
            shader.setFloat("time", time);
            shader.setVector("coreColor", 0.5f, 0.0f, 1.0f); // Purple
            shader.setVector("outlineColor", 0.0f, 0.5f, 1.0f); // Blue
            shader.setVector("effectColor", 0.8f, 0.2f, 1.0f);
        }
        
        // Draw the laser quad based on distance
        matrixStack.method_22903();
        
        // Match player rotation
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            float yaw = client.field_1724.method_5705(client.method_1488());
            float pitch = client.field_1724.method_5695(client.method_1488());
            
            // Adjust matrix so Z+ points forward corresponding to where the player looks
            matrixStack.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-yaw + 180));
            matrixStack.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(-pitch));
        }

        Matrix4f posMat = matrixStack.method_23760().method_23761();
        
        ShaderProgram currentShader = VeilRenderSystem.getShader();
        if (currentShader != null) {
            // Provide projection and view matrices explicitly for the custom geometry
            try {
                currentShader.setMatrix("ProjMat", RenderSystem.getProjectionMatrix());
                currentShader.setMatrix("ModelViewMat", posMat);
            } catch (Exception e) {
                // Ignore if uniforms don't exactly match or aren't generated
            }
        }
        
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_1349();
        
        float width = 1.5f; // Beam width
        
        buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
        
        // Top quad
        buffer.method_22918(posMat, -width, width, 0).method_22913(0f, 0f).method_1344();
        buffer.method_22918(posMat, width, width, 0).method_22913(0f, 1f).method_1344();
        buffer.method_22918(posMat, width, width, distance).method_22913(1f, 1f).method_1344();
        buffer.method_22918(posMat, -width, width, distance).method_22913(1f, 0f).method_1344();

        // Bottom quad
        buffer.method_22918(posMat, -width, -width, distance).method_22913(1f, 0f).method_1344();
        buffer.method_22918(posMat, width, -width, distance).method_22913(1f, 1f).method_1344();
        buffer.method_22918(posMat, width, -width, 0).method_22913(0f, 1f).method_1344();
        buffer.method_22918(posMat, -width, -width, 0).method_22913(0f, 0f).method_1344();
        
        // Side quad 1
        buffer.method_22918(posMat, -width, -width, 0).method_22913(0f, 0f).method_1344();
        buffer.method_22918(posMat, -width, -width, distance).method_22913(1f, 0f).method_1344();
        buffer.method_22918(posMat, -width, width, distance).method_22913(1f, 1f).method_1344();
        buffer.method_22918(posMat, -width, width, 0).method_22913(0f, 1f).method_1344();

        // Side quad 2
        buffer.method_22918(posMat, width, width, 0).method_22913(0f, 1f).method_1344();
        buffer.method_22918(posMat, width, width, distance).method_22913(1f, 1f).method_1344();
        buffer.method_22918(posMat, width, -width, distance).method_22913(1f, 0f).method_1344();
        buffer.method_22918(posMat, width, -width, 0).method_22913(0f, 0f).method_1344();

        tessellator.method_1350();
        
        matrixStack.method_22909();
        
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }
}