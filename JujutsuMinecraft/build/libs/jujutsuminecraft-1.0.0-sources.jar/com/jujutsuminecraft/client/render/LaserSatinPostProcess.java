package com.jujutsuminecraft.client.render;

import ladysnake.satin.api.managed.ManagedShaderEffect;
import ladysnake.satin.api.managed.ShaderEffectManager;
import net.minecraft.class_2960;

public class LaserSatinPostProcess {
    public static ManagedShaderEffect LASER_VIGNETTE_BLUR;

    public static void init() {
        LASER_VIGNETTE_BLUR = ShaderEffectManager.getInstance().manage(
            new class_2960("jujutsuminecraft", "shaders/post/laser_vignette_blur.json")
        );
    }
}