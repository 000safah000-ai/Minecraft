package com.jujutsuminecraft.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

public class LaserKeybind {
    public static class_304 laserKey;
    public static boolean isLaserActive = false;

    public static void register() {
        laserKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.jujutsuminecraft.laser",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_G,
            "category.jujutsuminecraft"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (laserKey.method_1436()) {
                isLaserActive = !isLaserActive;
                // TODO: Send packet to server for multiplayer sync
            }
        });
    }
}